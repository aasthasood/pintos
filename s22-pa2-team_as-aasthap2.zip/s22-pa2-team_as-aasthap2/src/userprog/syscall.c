#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include <list.h>
#include "threads/palloc.h"

static void syscall_handler (struct intr_frame *);
static bool addr_valid(const uint64_t *uaddr);
static int write (int, const void *, unsigned);
static void exit(int status);
static int filesize (int fd);
static bool create (const char *file, unsigned initial_size);
static void seek (int fd, unsigned position);
static unsigned tell (int fd);
static int read (int fd, void *buffer, unsigned size);
static int wait (pid_t pid);
static int exec_proc(char *file_name);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
   int *esp = f->esp; 
   int system_call = *(int*)esp;
   int status;
   switch(system_call)
   {
     case 0:
        halt();
     case 1:
        status=*(((int *) esp) + 1);
        exit(status);
        break;  
     case 2:
        exec((char *) *(esp + 1));
        break; 
     case 3:
	wait (*(esp + 1));
	break;
     case 4:
        create((char *) *(esp + 1), *(esp + 2));
        break;
     case 7:
        filesize(*(esp + 1));
	break;   
     case 8:
        read(*(((int *) esp) + 1),*(((int *) esp) + 2),*(((int *) esp) + 3));
        break;
     case 9:
        write(*(((int *) esp) + 1),*(((int *) esp) + 2),*(((int *) esp) + 3));
        break;	 
     case 10:
        seek(*(esp + 1), *(esp + 2));
	break;   
     case 11:
        tell(*(esp + 1));
	break;     
   }
}


static bool addr_valid(const uint64_t *uaddr)
{
  void *asptr = pagedir_get_page(thread_current()->pagedir, uaddr);
  if ((uaddr == NULL) || !(is_user_vaddr (uaddr)) || asptr==NULL)
    return false;  
  return true;
  
}

void halt()
{
   shutdown_power_off();
}

void exit(int status)   
{ 
   printf("%s: exit(%d)\n", thread_current ()->name, status);
   thread_exit();
}


int exec_proc(char *file_name){
	addr_valid(file_name);
	char *fn_copy = palloc_get_page(PAL_ZERO);
	if (fn_copy == NULL) {
		return -1;
	}
	int fl_size = strlen(file_name)+1;
	strlcpy(fn_copy, file_name, fl_size);
	char *asptr;
	fn_copy = strtok_r(fn_copy," ",&asptr);
	struct file* f = open(fn_copy);
	if(f!=NULL){
	  	close(f);
	  	return process_execute(file_name);
	 }
	 else{
	  	return -1;
	 }
}


int wait (pid_t pid){ 
  return process_wait(pid);
}

bool create (const char *file, unsigned initial_size){
   
    bool c = filesys_create(file, initial_size);
    return c;
}

int filesize (int fd){

   struct file *fl = fetch_fl(thread_current (), fd);
   int fsize = file_length(fl);
   return fsize;
}

int read (int fd, void *buffer, unsigned size){
  addr_valid(buffer);
  int r;
  if (fd == 1){
	r = - 1;
  }
  else if(fd < 1){
	for(int j = 0; j<size; j++){
	       ((char*)buffer)[j] = input_getc();
	}
	r = size;
  }
  
  else if(fd > 1){
	struct file *fl = fetch_fl(thread_current (), fd);
	if (fl == NULL)
	    return -1;
	else{
	    r = file_read(fl, buffer, size);
	}
   }
   return r;
}

/*int write(int fd,const void *buffer,unsigned size)
{
   addr_valid(buffer);
   int w;
   if (fd == 1){
	putbuf(buffer, size);
	w = size;
   }
   else if(fd<2){
	w = -1;
   }
   else{	
	struct file *fl = fetch_fl(thread_current (), fd);
	if(file == NULL){
		write_result = -1;
	}
	else{
		wr = file_write(file, buffer, size);
	}
   }
	
	return w;
}
*/
int write(int fd,const void *buffer,unsigned size)
{
   if(size>0 && addr_valid(buffer))
   {
      putbuf(buffer,size);
      return size;
   }
   else
   {
      return 0;
   }
}

void seek (int fd, unsigned position){
    struct file *fl = fetch_fl(thread_current (), fd);
    if(fl){
	file_seek(fl,position);
    }
}



unsigned tell (int fd){
    struct file *fl = fetch_fl(thread_current (), fd);
    if(fl){
	unsigned t = file_tell(fl);
	return t;
    }
    else{
        return -1;
    }
}

