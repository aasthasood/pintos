#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/synch.h"
#include <list.h>
#include "threads/palloc.h"
static void syscall_handler(struct intr_frame *);
static bool addr_valid(const uint64_t *uaddr);
static int write(int, const void *, unsigned);
static void exit(int status);
static void close(int filedesc);
static int open(const char *file);
static void halt();
static bool create(const char *filename,unsigned size);
static bool remove(const char *filename);
static int read(int ,const void *,unsigned);
static int filesize(int);
static pid_t execute(const char *cmd_line);
static void seek(int,unsigned);
static unsigned tell(int);
int gfd_count=2;
static struct lock filesys_lock;
void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&filesys_lock);
  //list_init(&thread_current()->open_file_list);
}
static bool addr_valid(const uint64_t *uaddr)
{
  if ((uaddr == NULL))
	return false;
  if(!(is_user_vaddr(uaddr)))
	return false;
  void *asptr = pagedir_get_page(thread_current()->pagedir, uaddr);
  if(asptr==NULL)
  	return false;
  return true;
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
   int *esp = f->esp; 
   int system_call = *(int*)esp;
   int status;
   if(!addr_valid((int*)esp))
	exit(-1);
   if(!addr_valid(((int*)esp)+1))
	exit(-1);
   if(!addr_valid(((int*)esp)+2))
	exit(-1);
   if(!addr_valid(((int*)esp)+3))
	exit(-1);
   switch(system_call)
   {
     case 0:
        halt();
        break;
     case 1:
        status=*(((int *) esp) + 1);
        exit(status);
        break;
     case 4:
        f->eax=create(*(((int *) esp) + 1),*(((int *) esp) + 2));
        break;
     case 5:
	remove(*(((int *) esp) + 1));
	break;
     case 6:
        f->eax=open(*(((int *) esp) + 1));
        break;
     case 7:
        f->eax=filesize(*(((int *) esp) + 1));
        break;
     case 8:
        f->eax=read(*(((int *) esp) + 1),*(((int *) esp) + 2),*(((int *) esp) + 3));
        break;
     case 9:
        f->eax=write(*(((int *) esp) + 1),*(((int **) esp) + 2),*(((int *) esp) + 3));
        break;
     case 10:
        seek(*(((int *) esp) + 1),*(((int **) esp) + 2));
        break;
     case 11:
        f->eax=tell(*(((int *) esp) + 1));
        break;
     case 12:
	close(*(((int *) esp) + 1));
	break;
     default:
	break;   
   }
}


void halt()
{
   shutdown_power_off();
}

void exit(int status)   
{ 
   printf("%s: exit(%d)\n", thread_current ()->name, status);
   thread_exit();
}

bool create(const char *filename,unsigned size)
{
   bool k;
   //printf("Hello Wpord\n");
   //printf("%s\n",filename);
   //printf("%d\n",size);
   if(!addr_valid(filename))
	exit(-1);
   else
   {
	lock_acquire (&filesys_lock);
	k= filesys_create(filename,size);
        lock_release(&filesys_lock);
        return k;
   }
   return false;       
}

int open(const char *file)
{
   //printf("hello world\n");
   //printf("%s\n",file);
   if(!addr_valid(file))
	exit(-1);
   if(file==NULL)
	return -1;
   else
   {
     struct open_file *f=palloc_get_page(0);
     if(f==NULL)
	return -1;
     f->fd=gfd_count;
     lock_acquire(&filesys_lock);
     f->file=filesys_open(file);
     lock_release(&filesys_lock);
     if(f->file!=NULL)
     {      
	list_push_back(&thread_current()->open_file_list,&f->elem);
        thread_current()->fd_count=f->fd;
        gfd_count++;
        return f->fd;
     }
     return -1;
   }
}

int filesize(int fd)
{
   int size=0;
   struct open_file *f=palloc_get_page(0);
   struct list_elem *e;
   for (e = list_begin (&thread_current()->open_file_list); e != list_end (&thread_current()->open_file_list); e = list_next (e))
   {
      f=list_entry(e,struct open_file,elem);
      if(f!=NULL)
      {
         if(f->fd=fd)
         {
            lock_acquire(&filesys_lock);
            size=file_length(f->file);
            lock_release(&filesys_lock);
            //printf("Size:%d\n",k);
            return size;
         }
      }  
   }   
}

bool remove(const char *filename)
{
   if(!addr_valid(filename))
	exit(-1);
   else
	return filesys_remove(filename); 
}

int read(int fd,const void *buffer,unsigned size)
{
   int i,k=0;
   //printf("Hello:%d\n",fd);
   if(!addr_valid(buffer))
   {
	exit(-1);
   }
   if(fd<0 || fd==NULL)
        exit(-1);	
   if(size==0)
	   return 0;
   if(fd==0)
   {
      for(i=0;i<size;i++)
      {
         input_getc();
      }
      return size;
   }
   else
   {
       struct open_file *f=palloc_get_page(0);
       struct list_elem *e;
       for (e = list_begin (&thread_current()->open_file_list); e != list_end (&thread_current()->open_file_list); e = list_next (e))
       {
          f=list_entry(e,struct open_file,elem);
          if(f!=NULL)
          {
             if(f->fd=fd)
             {
                lock_acquire(&filesys_lock);
                k=file_read(f->file,buffer,size);
                lock_release(&filesys_lock);
                //printf("Size:%d\n",k);
                return k;
             }
          }  
       }
       if(f->file==NULL)
           exit(-1);
   }
   return -1;
}


int write(int fd,const void *buffer,unsigned size)
{
   /*if(!addr_valid(buffer))
	exit(-1);
   else if(fd==1 && addr_valid(buffer))
   {
      putbuf(buffer,size);
      return size;
   }
   else
   {
      return 0;
   }*/
   if(fd==1 && addr_valid(buffer))
   {
      putbuf(buffer,size);
      return size;
   }
   else
   {
      if(!addr_valid(buffer))
		exit(-1);
      int k=0;
      struct open_file *f=palloc_get_page(0);
      struct list_elem *e;
      for (e = list_begin (&thread_current()->open_file_list); e != list_end (&thread_current()->open_file_list); e = list_next (e))
      {
          f=list_entry(e,struct open_file,elem);
          if(f!=NULL)
          {
             if(f->fd==fd)
             {
                 lock_acquire(&filesys_lock);
                 k=file_write(f->file,buffer,size);
                 lock_release(&filesys_lock);
	         return k;
             }
          }  
      }
   }
}

void seek(int fd,unsigned position)
{
  struct open_file *f=palloc_get_page(0);
  struct list_elem *e;
  for (e = list_begin (&thread_current()->open_file_list); e != list_end (&thread_current()->open_file_list); e = list_next (e))
  {
      f=list_entry(e,struct open_file,elem);
      if(f!=NULL)
      {
         if(f->fd=fd)
         {
             lock_acquire(&filesys_lock);
             file_seek(f->file,position);
             lock_release(&filesys_lock);
             return;
         }
      }  
  }
}

unsigned tell(int fd)
{
  struct open_file *f=palloc_get_page(0);
  unsigned k;
  struct list_elem *e;
  for (e = list_begin (&thread_current()->open_file_list); e != list_end (&thread_current()->open_file_list); e = list_next (e))
  {
      f=list_entry(e,struct open_file,elem);
      if(f!=NULL)
      {
         if(f->fd=fd)
         {
             lock_acquire(&filesys_lock);
             k=file_tell(f->file);
             lock_release(&filesys_lock);
             return k;
         }
      }  
  }
}

void close(int filedesc)
{
   if(filedesc==NULL)
	return;
   struct open_file *f=palloc_get_page(0);
   struct list_elem *e;
   for (e = list_begin (&thread_current()->open_file_list); e != list_end (&thread_current()->open_file_list); e = list_next (e))
   {
      f=list_entry(e,struct open_file,elem);
      if(f!=NULL)
      {
         if(f->fd=filedesc)
         {
              lock_acquire(&filesys_lock);
              file_close(f->file);
	      lock_release(&filesys_lock);
              return;
         }
      }  
   }
   return;
}
